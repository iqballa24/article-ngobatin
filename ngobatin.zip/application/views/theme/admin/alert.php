<div class="flash-data" data-tempdata="<?= $this->session->tempdata('message') ?>"></div>
<div class="flash-data-info" data-tempdata="<?= $this->session->tempdata('info') ?>"></div>
<div class="flash-data-error" data-tempdata="<?= $this->session->tempdata('error') ?>"></div>
<div class="flash-data-confirm" data-tempdata="<?= $this->session->tempdata('confirm') ?>"></div>